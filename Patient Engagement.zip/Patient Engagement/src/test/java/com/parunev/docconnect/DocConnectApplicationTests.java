package com.parunev.docconnect;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
@Disabled
class DocConnectApplicationTests {

    @Test
    @Disabled
    void contextLoads() {
    }

}
