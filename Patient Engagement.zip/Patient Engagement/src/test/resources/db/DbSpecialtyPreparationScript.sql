insert into specialties(specialty_name, image_url)
VALUES ('Cardiology', 'https://images.pexels.com/photos/7659564/pexels-photo-7659564.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1');
insert into specialties(specialty_name, image_url)
VALUES ('Orthopedics', 'https://images.pexels.com/photos/7446990/pexels-photo-7446990.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1');


