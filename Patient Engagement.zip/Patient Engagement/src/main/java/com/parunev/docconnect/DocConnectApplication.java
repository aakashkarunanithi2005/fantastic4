package com.parunev.docconnect;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DocConnectApplication {

    public static void main(String[] args) {
        SpringApplication.run(DocConnectApplication.class, args);
    }

}
